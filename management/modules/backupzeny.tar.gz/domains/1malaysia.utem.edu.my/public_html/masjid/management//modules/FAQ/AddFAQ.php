<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head><script language="javascript" src="calendar.js"></script>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Add New F.A.Q</title>
</head>

<body>

<form id="form1" name="form1" method="post" action="processFAQ.php">
<table width="490" border="0">
  <tr>
    <td height="36" colspan="2" align="left"><strong>ADD NEW F.A.Q</strong></td>
    </tr>
  <tr>
    <td width="83" align="left" valign="top">Question :</td>
    <td width="372">	
	  <label>
        <textarea name="Question" cols="45" rows="3" id="Question"></textarea>
      </label>
   </td>
  </tr>
  <tr>
    <td align="left" valign="top">Answer :</td>
    <td><label>
      <textarea name="Answer" id="Answer" cols="45" rows="5"></textarea>
    </label></td>
  </tr>
  <tr>
    <td align="left">Date : </td>
    <td><label>
    <?php
		require_once('classes/tc_calendar.php');

		$myCalendar = new tc_calendar("date1", true);
		$myCalendar->setIcon("images/iconCalendar.gif");
		$myCalendar->setDate(1, 1, 2000);

		$myCalendar->writeScript();	  
	?>
    </label></td>
  </tr>
  <tr>
    <td align="left">Author :</td>
    <td><label>
      <input name="Author" type="text" id="Author" size="45" />
    </label></td>
  </tr>
  <tr>
    <td align="left">&nbsp;</td>
    <td><label>
      <input type="submit" name="Submit" id="Submit" value="Insert New F.A.Q" />
      </label></td>
  </tr>
</table>


 </form>
</body>
</html>