<html>
<head>
<script type="text/javascript">

function popUp(URL) {
day = new Date();
id = day.getTime();
eval("page" + id + " = window.open(URL, '" + id + "', 'toolbar=0,scrollbars=1,location=1,statusbar=0,menubar=0,resizable=1,width=1024,height=600,left =-10,top = 0');");
}
</script>


</head>

<body>

<form id="form1" name="form1" method="post" action="">
  <p>&nbsp;</p>
  
  
  
  <table width="1023" border="0" align="center">
    <tr bgcolor="#EAEAEA">
      <td width="375"><div align="center"><b><font face="Calibri" color="#666666">F.A.Q Question</b></div></td>
      <td width="140"><div align="center"><b><font face="Calibri" color="#666666">Author</b></div></td>
      <td width="134"><div align="center"><b><font face="Calibri" color="#666666">Date</b></div></td>
      <td width="100"><div align="center"><b><font face="Calibri" color="#666666">View</b></div></td>
      <td width="100"><div align="center"><b><font face="Calibri" color="#666666">Update</b></div></td>
      <td width="100"><div align="center"><b><font face="Calibri" color="#666666">Delete</b></div></td>
    </tr>
    </table>
    <table width="1023" border="0" align="center">
    <?php 
	
	$host = "perfectworld.sytes.net";
	$username = "bengkel2";
	$password = "ftmk";
	$db_name = "bengkel2";
	$tbl_name = "faq";

	mysql_connect("$host","$username","$password")or die("cannot connect");
	mysql_select_db("$db_name")or die("Database did not exist");
	
	$get_data = "SELECT FaqID, Question, Answer, Date, Author FROM faq ORDER BY FaqID DESC ";
	$result = mysql_query($get_data);
	
 		while ($row=mysql_fetch_array($result))
			{
   			echo ("<tr><td width='375' align='left'><font face='Calibri' color='#666666'>$row[Question]</td>");
    		echo ("<td width='140' align='center'><font face='Calibri' color='#666666'>$row[Author]</td>");
    		echo ("<td width='134' align='center'><font face='Calibri' color='#666666'>$row[Date]</td>");
    		echo ("<td width='100' align='center'><a href=\"javascript:popUp('view_post.php?FaqID=$row[FaqID]')\"><img src='image/view.png' width='30' border='0' title='View' ></a></td>");
    		echo ("<td width='100' align='center'><a href=\"update_post.php?FaqID=$row[FaqID]\"><img src='image/update.png' width='30' border='0' title='Update'></a></td>");
			echo ("<td width='100' align='center'><a href=\"process_delete_post.php?FaqID=$row[FaqID]&action=delete\" onclick=\"javascript:return confirm('Are You Sure Want To Delete This Post?')\"><img src='image/delete.png' width='30' border='0' title='Delete'></a></td></tr>");
			echo ("<tr><td colspan='7'><hr></td></tr>");
			}
	?>
   
     </table></td>
      </tr>
    </table>
  <div align="center"></div>
  <p>&nbsp;</p>
  <p>&nbsp;</p>
</form>
<p>&nbsp;</p>
</body>
</html>
