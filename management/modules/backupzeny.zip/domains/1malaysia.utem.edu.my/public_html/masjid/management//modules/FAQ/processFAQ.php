<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>F.A.Q Process</title>
</head>

<body>
<?php
$host = "perfectworld.sytes.net";
$username = "bengkel2";
$password = "ftmk";
$db_name = "bengkel2";
$tbl_name = "faq";

mysql_connect("$host","$username","$password")or die("cannot connect");
mysql_select_db("$db_name")or die("Database did not exist");

$Question = $_POST['Question'];
$Answer = $_POST['Answer'];
$theDate = isset($_REQUEST["date1"]) ? $_REQUEST["date1"] : "";
$Author = $_POST['Author'];

if($Question =="")
{
	echo"<script> alert('Empty Field on Question');</script>";
	echo"<script> history.go(-1);</script>";
}
else if($Answer =="")
{
	echo"<script> alert('Empty Field on Answer');</script>";
	echo"<script> history.go(-1);</script>";
}
else if($Author =="")
{
	echo"<script> alert('Empty Field on Author');</script>";
	echo"<script> history.go(-1);</script>";
}

// sebelum ni Faq ID pakai manual...so lpas develop auto generate, no need this orange block anymore :)
/* else if($FaqID =="")
{
	echo"<script> alert('Empty Field on Id');</script>";
	echo"<script> history.go(-1);</script>";
} */

else if($theDate =="")
{
	echo"<script> alert('Empty Field on Date');</script>";
	echo"<script> history.go(-1);</script>";
}
else
{
	$result = mysql_query("SELECT MAX(FaqID)AS MAXID FROM faq");
	while($row = mysql_fetch_array($result))
 	{
		$maxid2 = $row['MAXID'] + 1;
		
 	}
	
	$query = "INSERT INTO faq (FaqID, Question, Answer, Date, Author) VALUES ('".$maxid2."','".$Question."','".$Answer."','".$theDate."','".$Author."')";
	mysql_query($query)or die(error);
	
	echo "<script>alert('F.A.Q Has Sucessfully Added To Database')</script>";
}
	echo "Current ID :$maxid2<br />"; 
	echo "Question  : $Question <br />";
	echo "Answer    : $Answer <br />";
	echo "Author    : $Author <br />";
	echo "Date      : $theDate <br />";
?>

</body>
</html>
