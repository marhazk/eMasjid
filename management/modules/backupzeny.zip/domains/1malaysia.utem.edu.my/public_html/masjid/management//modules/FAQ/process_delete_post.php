<?php 

		$host = "perfectworld.sytes.net";
		$username = "bengkel2";
		$password = "ftmk";
		$db_name = "bengkel2";
		$tbl_name = "faq";
		
		mysql_connect("$host","$username","$password")or die("cannot connect");
		mysql_select_db("$db_name")or die("Database did not exist");


		$FaqID=$_GET["FaqID"];
		$order = "DELETE FROM faq WHERE FaqID='$FaqID'";
		  
		mysql_query($order);
		
		echo "<script>alert('Post Deleted!')</script>";
		echo "<script>window.location='manage_FAQ.php'</script>";
?>
