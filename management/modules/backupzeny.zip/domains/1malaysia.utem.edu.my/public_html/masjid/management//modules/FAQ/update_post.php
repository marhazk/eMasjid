<?php 	

	$host = "perfectworld.sytes.net";
	$username = "bengkel2";
	$password = "ftmk";
	$db_name = "bengkel2";
	$tbl_name = "faq";

	mysql_connect("$host","$username","$password")or die("cannot connect");
	mysql_select_db("$db_name")or die("Database did not exist");

	$FaqID = $_GET["FaqID"];
    $order = "SELECT * FROM faq where FaqID='$FaqID'";
    $result = mysql_query($order);
    $row = mysql_fetch_array($result);
?>	
    <html>
    <head>
    <script type="text/javascript"></script>
    <style type="text/css">
    <!--
    .style2 {font-family: "terminator Cyr 4";
        font-size: 12px;
        color: #FF6600;
    }
    -->
    </style>
    </head>
    
    <body>
    
    <form id="viewpost" name="updatepost" method="post" action="process_update_post.php">
	<table width="980" border="0" align="center">
    <tr>
    <td width="623"><textarea class="ckeditor" name="Question" cols="80" rows="5" id="Question" align="center"><?php echo $row['Question']; ?></textarea></td>
    <td width="347" rowspan="3" valign="top">
                
    </div>
	<label><table width="339" height="60" border="0">
              <tr>
                <td>Date</td>
                <td>:<label>
                <input type="" id="Date" name="Date" value="<?php echo $row['Date']; ?>"></label></td>
          </tr>
               <tr>
                 <td width="60" height="31">Author </td>
                 <td width="269">:
                 <label>
                 <input type="" id="Author" name="Author" value="<?php echo $row['Author']; ?>"></label>
                 <input type="hidden" id="FaqID" name="FaqID" value="<?php echo $row['FaqID']; ?>" readonly  /> </td>
          </tr>
                 </table>
			<div align="left">
			<a href="manage_FAQ.php"><input type="button" name="cancel" value="&lt; Cancel Update" align="left" />
			</a>
			<input type="submit" name="button_UpdatePost" id="button_UpdatePost" value="Update FAQ &gt;" align="left" />
            </div>
             </p>
      </label>
      </label></td>
               </tr>
               <tr>
                <td width="623">
       <textarea class="ckeditor" name="Answer" cols="80" rows="10" id="Answer" align="center"><?php echo $row['Answer']; ?></textarea>
               </div></td>
              </tr>
              <tr>
              <td><label></label>
                  <label></label></td>
        	  </tr>
      </table>
      <p></p>
    </form>
</body>
</html>




