<?php 	

	$host = "perfectworld.sytes.net";
	$username = "bengkel2";
	$password = "ftmk";
	$db_name = "bengkel2";
	$tbl_name = "faq";

	mysql_connect("$host","$username","$password")or die("cannot connect");
	mysql_select_db("$db_name")or die("Database did not exist");

	$FaqID = $_GET["FaqID"];
    $order = "SELECT * FROM faq where FaqID='$FaqID'";
    $result = mysql_query($order);
    $row = mysql_fetch_array($result);
?>	
    <html>
    <head>
    <script type="text/javascript"></script>
    <style type="text/css">
    <!--
    .style2 {font-family: "terminator Cyr 4";
        font-size: 12px;
        color: #FF6600;
    }
    -->
    </style>
    </head>
    
    <body>
    
    <form id="viewpost" name="viewpost">
	<table width="980" border="0" align="center">
    <tr>
    <td width="623"><textarea class="ckeditor" name="content_text" cols="80" rows="5" id="content_text" align="center" readonly ><?php echo $row['Question']; ?></textarea></td>
    <td width="347" rowspan="3" valign="top">
                
    </div>
	<label><table width="339" height="60" border="0">
              <tr>
                <td>Date</td>
                <td>:
                    <label readonly><?php echo $row['Date']; ?></label></td>
               </tr>
               <tr>
                 <td width="60" height="31">Author </td>
                 <td width="269">:
                    <label readonly><?php echo $row['Author']; ?></label></td>
                </tr>
                 </table><div align="center">

                 <a href="manage_home.php"><input type="button" name="back" value=" Back " align="center" onClick="self.close()"/></a> <br />
                 </div>
			     <br />
      </label>
      </label></td>
               </tr>
               <tr>
                <td width="623">
       <textarea class="ckeditor" name="content_text" cols="80" rows="10" id="content_text" align="center" readonly ><?php echo $row['Answer']; ?></textarea>
               </div></td>
              </tr>
              <tr>
              <td><label></label>
                  <label></label></td>
        	  </tr>
      </table>
      <p></p>
    </form>
</body>
</html>
